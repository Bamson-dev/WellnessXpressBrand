import Link from "next/link";
import Image from "next/image";
import { getContact, getSetting } from "@/lib/settings";
import HeaderClient from "@/components/HeaderClient";
import { IconTruck } from "@/components/icons";
import { FREE_DELIVERY_TITLE } from "@/lib/site";

export const NAV = [
  { href: "/", label: "Home" },
  { href: "/shop", label: "Shop" },
  { href: "/category/individual", label: "Individual Products" },
  { href: "/category/combos", label: "Combo Sets" },
  { href: "/about", label: "About Us" },
  { href: "/contact", label: "Contact" },
];

export default function Header() {
  const announcement = getSetting<string>("announcement");
  const contact = getContact();
  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/85">
      <div className="bg-brand-900 text-white">
        <p className="container-x flex items-center justify-center gap-2 py-2 text-center text-[13px] leading-snug sm:text-sm">
          <IconTruck className="h-4 w-4 shrink-0" />
          <Link href="/shipping" className="font-bold tracking-wide hover:underline">{FREE_DELIVERY_TITLE}</Link>
          {announcement ? <span className="hidden font-medium text-white/85 md:inline">· {announcement}</span> : null}
        </p>
      </div>
      <div className="border-b border-neutral-200">
        <div className="container-x flex h-16 items-center gap-3 sm:h-[72px]">
          <Link href="/" className="flex shrink-0 items-center gap-2" aria-label="WellnessXpressBrand home">
            <Image src="/brand/logo-480.webp" alt="" width={45} height={40} className="h-10 w-auto sm:h-11" priority />
            <span className="leading-tight">
              <span className="block text-[15px] font-bold text-brand-900 sm:text-base">WellnessXpress</span>
              <span className="hidden text-[11px] font-medium text-neutral-500 sm:block">Your Weightloss Journey Starts Here.</span>
            </span>
          </Link>
          <nav aria-label="Main" className="ml-6 hidden flex-1 items-center gap-1 lg:flex">
            {NAV.map((n) => (
              <Link key={n.href} href={n.href} className="rounded-full px-3 py-2 text-[15px] font-medium text-neutral-700 transition hover:bg-brand-50 hover:text-brand-900">
                {n.label}
              </Link>
            ))}
          </nav>
          <HeaderClient nav={NAV} whatsapp={contact.whatsapp} />
        </div>
      </div>
    </header>
  );
}
